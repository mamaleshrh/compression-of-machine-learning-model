Install miniconda locally for more reliable experience and easy package managing.

1.Download Miniconda
  wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh

2.Install Miniconda
  bash Miniconda3-latest-Linux-x86_64.sh

3.Activate Miniconda
  source miniconda3/bin/activate

4.Create enviroment
  conda create --name Paper21 python=3.9

5.Activate enviroment
  conda activate Paper21

6.Installation of required libraries
   pip install requirements.txt (file attached in the folder)
   - If any library is not found then remove it from the text file
   - If download of any library terminates in the middle then rerun the above command

DATASET DOWNLOAD - for adding the dataset we can manually add the dataset zip file in the directory or we can first store the dataset in cache then access it. (Whenever job is submitted then the supercomputer cannot access the internet).

- How to store dataset in cache
-> Get access to interactive terminal
   srun --partition=cpu --nodes=1 --time=04:00:00 --ntasks-per-node=40  --pty bash -i
-> Run the python commands to move the data in the cache 
   import tensorflow as tf
   (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

CODE EXECUTION

(Alexnet Model) 
Whenever at the home directory run the following commands
  source miniconda/bin/activate
  conda activate Paper21
  cd Group21/Paramshivay
  sbatch slrum_file.sh

(VGG16 Model)
We decided to run the file in interactive terminal this time (just for checking how it works)
Run the following commands
  srun --partition=cpu --nodes=1 --time=04:00:00 --ntasks-per-node=40  --pty bash -i
  source miniconda/bin/activate
  conda activate Paper21
  cd Group21/Paramshivay2
  python VGG16_MNIST.py