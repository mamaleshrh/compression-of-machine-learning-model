Install miniconda locally for more reliable experience and easy package managing.

1.Download Miniconda
  wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh

2.Install Miniconda
  bash Miniconda3-latest-Linux-x86_64.sh

3.Activate Miniconda
  source miniconda3/bin/activate

4.Create enviroment
  conda create --name Paper8 python=3.9

5.Activate enviroment
  conda activate Paper8

6.Installation of required libraries
   conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia
   conda install numpy
   conda install matplotlib

DATASET DOWNLOAD - For this paper we have directly added the datazet zip file after downloading it from website and store it in "data" folder
website - https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz

CODE EXECUTION

Run the following commands whenever in home directory
  source miniconda/bin/activate
  conda activate Paper8
  cd Group21/Paramshivay3
  sbatch slrum_file.sh