#!/bin/sh
#SBATCH -N 1
#SBATCH --ntasks-per-node=40
#SBATCH --time=01:00:00
#SBATCH --job-name=Alexnet_MNIST
#SBATCH --error=Alexnet_MNIST_Err.txt
#SBATCH --output=Alexnet.txt
#SBATCH --partition=cpu

python Alexnet_MNIST.py